﻿namespace MiPrimeGame_0._1__BETA_
{
    partial class VenHistorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BotonCerrarHisto = new Button();
            groupBox1 = new GroupBox();
            ListaHistorial = new ListBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // BotonCerrarHisto
            // 
            BotonCerrarHisto.Location = new Point(212, 415);
            BotonCerrarHisto.Name = "BotonCerrarHisto";
            BotonCerrarHisto.Size = new Size(384, 23);
            BotonCerrarHisto.TabIndex = 19;
            BotonCerrarHisto.Text = "Volver al menu principal";
            BotonCerrarHisto.UseVisualStyleBackColor = true;
            BotonCerrarHisto.Click += BotonCerrarHisto_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(ListaHistorial);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 397);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tabla de victorias de cada partida";
            // 
            // ListaHistorial
            // 
            ListaHistorial.FormattingEnabled = true;
            ListaHistorial.ItemHeight = 15;
            ListaHistorial.Location = new Point(6, 22);
            ListaHistorial.Name = "ListaHistorial";
            ListaHistorial.Size = new Size(764, 364);
            ListaHistorial.TabIndex = 0;
            // 
            // VenHistorial
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BotonCerrarHisto);
            Controls.Add(groupBox1);
            Name = "VenHistorial";
            Text = "VenHistorial";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button BotonCerrarHisto;
        private GroupBox groupBox1;
        private ListBox ListaHistorial;
    }
}