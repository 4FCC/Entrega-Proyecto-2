using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace MiPrimeGame_0._1__BETA_
{
    public partial class Inicio : Form
    {
        private ClassVariables classVariables;

        public Inicio()
        {
            InitializeComponent();
        }

        // Bool para bloquear el juego
        private bool ajustesCerrados = false;

        private void BotonAjustes_Click_1(object sender, EventArgs e)
        {
            VenAjustes venAjustes = new VenAjustes();
            venAjustes.ShowDialog(); // Cambia Show() por ShowDialog()
            ajustesCerrados = true;
            classVariables = venAjustes.datosDeControles; // Obtener los datos de ajustes del segundo formulario
        }

        private void BotonSalir_Click(object sender, EventArgs e)
        {
            // Cerrar el formulario actual
            this.Close();
        }

        private void BotonHistorial_Click(object sender, EventArgs e)
        {
            // Abrir el formulario VenHistorial y pasar la instancia de ClassVariables
            VenHistorial venHistorial = new VenHistorial(classVariables);
            venHistorial.Show();
        }

        private void BotonJugar_Click(object sender, EventArgs e)
        {
            if (ajustesCerrados)
            {
                VenHistorial venHistorial = new VenHistorial(classVariables);
                Juego1 juego1 = new Juego1(classVariables);
                juego1.FormClosing += (s, args) => venHistorial.Show(); // Mostrar el formulario de historial al cerrar el formulario de juego
                juego1.ShowDialog(); // Utilizar ShowDialog en lugar de Show
            }
            else
            {
                MessageBox.Show("Por favor, configure los ajustes antes de jugar.");
            }
        }
    }
}
