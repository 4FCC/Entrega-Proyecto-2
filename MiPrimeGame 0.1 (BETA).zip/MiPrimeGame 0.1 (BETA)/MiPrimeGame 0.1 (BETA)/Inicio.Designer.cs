﻿namespace MiPrimeGame_0._1__BETA_
{
    partial class Inicio
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TituloDelGame = new Label();
            BotonAjustes = new Button();
            BotonJugar = new Button();
            BotonHistorial = new Button();
            BotonSalir = new Button();
            SuspendLayout();
            // 
            // TituloDelGame
            // 
            TituloDelGame.AutoSize = true;
            TituloDelGame.FlatStyle = FlatStyle.System;
            TituloDelGame.Location = new Point(356, 142);
            TituloDelGame.Name = "TituloDelGame";
            TituloDelGame.Size = new Size(96, 15);
            TituloDelGame.TabIndex = 0;
            TituloDelGame.Text = "League of Words";
            TituloDelGame.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // BotonAjustes
            // 
            BotonAjustes.Location = new Point(303, 213);
            BotonAjustes.Name = "BotonAjustes";
            BotonAjustes.Size = new Size(203, 23);
            BotonAjustes.TabIndex = 1;
            BotonAjustes.Text = "Ajustes de Juego";
            BotonAjustes.UseVisualStyleBackColor = true;
            BotonAjustes.Click += BotonAjustes_Click_1;
            // 
            // BotonJugar
            // 
            BotonJugar.Location = new Point(303, 242);
            BotonJugar.Name = "BotonJugar";
            BotonJugar.Size = new Size(203, 23);
            BotonJugar.TabIndex = 2;
            BotonJugar.Text = "Empezar juego";
            BotonJugar.UseVisualStyleBackColor = true;
            BotonJugar.Click += BotonJugar_Click;
            // 
            // BotonHistorial
            // 
            BotonHistorial.Location = new Point(303, 271);
            BotonHistorial.Name = "BotonHistorial";
            BotonHistorial.Size = new Size(203, 23);
            BotonHistorial.TabIndex = 3;
            BotonHistorial.Text = "Historial de partidas";
            BotonHistorial.UseVisualStyleBackColor = true;
            BotonHistorial.Click += BotonHistorial_Click;
            // 
            // BotonSalir
            // 
            BotonSalir.Location = new Point(303, 300);
            BotonSalir.Name = "BotonSalir";
            BotonSalir.Size = new Size(203, 23);
            BotonSalir.TabIndex = 4;
            BotonSalir.Text = "Salir del juego";
            BotonSalir.UseVisualStyleBackColor = true;
            BotonSalir.Click += BotonSalir_Click;
            // 
            // Inicio
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BotonSalir);
            Controls.Add(BotonHistorial);
            Controls.Add(BotonJugar);
            Controls.Add(BotonAjustes);
            Controls.Add(TituloDelGame);
            Name = "Inicio";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label TituloDelGame;
        private Button BotonAjustes;
        private Button BotonJugar;
        private Button BotonHistorial;
        private Button BotonSalir;
    }
}