﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MiPrimeGame_0._1__BETA_
{
    public class ClassVariables
    {
        // Variables de VenAjustes
        public Image imagenTemporal;

        // Variables de tiempo de juego
        public int tiempoP;
        public int tiempoT;

        // Variables de Imagen de Jugador
        public Image imagenJ1;
        public Image imagenJ2;

        // Variables de Nombre de jugador 
        public string nombreJ1;
        public string nombreJ2;

        // Variables de Historial De Partidas
        public int TiempoWin;
        public string NombreWin;
        public int PuntosWin;
    }
}