﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPrimeGame_0._1__BETA_
{
    public partial class VenAjustes : Form
    {
        private ClassVariables classVariables = new ClassVariables();
        public ClassVariables datosDeControles;

        private string[] palabrasNoPermitidas = 
            { 
            "Cagada", 
            "Mugrosa", 
            "Maldita",
            "Diarreosa",
            "Cabrona",

            "Maricona",
            "Huevona",
            "Pendeja",
            "Tarada",
            "Jodida",

            "Culiada",
            "Gilipollesca",
            "Pelotuda",
            "Retardada",
            "Inutil",

            "Mongola",
            "Estupida",
            "Culo",
            "Cerda",
            "Cochambrosa",

            "Cochina",
            "Ruin",
            "Ramera",
            "Puta",
            "TragaSable",

            "Conchuda",
            "Ojete",
            "MamaHuevo",
            "Verga",
            "Concha",

        };

        private bool ContienePalabraNoPermitida(string texto)
        {
            foreach (string palabra in palabrasNoPermitidas)
            {
                if (texto.Contains(palabra))
                {
                    return true;
                }
            }
            return false;
        }

        public VenAjustes()
        {
            InitializeComponent();
        }

        public void pictureBoxP1_Click(object sender, EventArgs e)
        {
            // Establecer la imagen temporal como la imagen de pictureBoxP1
            classVariables.imagenTemporal = pictureBoxP1.Image;
        }

        public void pictureBoxP2_Click(object sender, EventArgs e)
        {
            // Establecer la imagen temporal como la imagen de pictureBoxP2
            classVariables.imagenTemporal = pictureBoxP2.Image;
        }

        public void pictureBoxP3_Click(object sender, EventArgs e)
        {
            // Establecer la imagen temporal como la imagen de pictureBoxP3
            classVariables.imagenTemporal = pictureBoxP3.Image;
        }

        public void pictureBoxP4_Click_1(object sender, EventArgs e)
        {
            // Establecer la imagen temporal como la imagen de pictureBoxP4
            classVariables.imagenTemporal = pictureBoxP4.Image;
        }

        public void pictureBoxP5_Click_1(object sender, EventArgs e)
        {
            // Establecer la imagen temporal como la imagen de pictureBoxP5
            classVariables.imagenTemporal = pictureBoxP5.Image;
        }

        public void BoxJ1_Click(object sender, EventArgs e)
        {
            // Asignar la imagen temporal a BoxJ1 si no es la misma que la imagen actual de BoxJ2
            if (classVariables.imagenTemporal != BoxJ2.Image)
            {
                classVariables.imagenJ1 = classVariables.imagenTemporal;
                BoxJ1.Image = classVariables.imagenTemporal;
            }
        }

        private void BoxJ2_Click(object sender, EventArgs e)
        {
            // Asignar la imagen temporal a BoxJ2 si no es la misma que la imagen actual de BoxJ1
            if (classVariables.imagenTemporal != BoxJ1.Image)
            {
                classVariables.imagenJ2 = classVariables.imagenTemporal;
                BoxJ2.Image = classVariables.imagenTemporal;
            }
        }

        private void BotonGS_Click(object sender, EventArgs e)
        {
            // Verificar si los nombres de usuario contienen palabras no permitidas
            if (ContienePalabraNoPermitida(NameJ1.Text) || ContienePalabraNoPermitida(NameJ2.Text))
            {
                MessageBox.Show("El nombre de usuario no está permitido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // No se permite salir del formulario hasta que se ingrese un nombre válido
            }

            // Inicializa la variable datosDeControles si es nula
            if (datosDeControles == null)
            {
                datosDeControles = classVariables;
            }

            // Asignar los valores de los controles a las propiedades de la clase ClassVariables
            classVariables.tiempoP = int.Parse(TextBoxTiempoP.Text);
            classVariables.tiempoT = int.Parse(TextBoxTiempoT.Text);
            classVariables.nombreJ1 = NameJ1.Text;
            classVariables.nombreJ2 = NameJ2.Text;

            // Cierra el formulario actual
            this.Close();
        }

        private void TextBoxTiempoP_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
