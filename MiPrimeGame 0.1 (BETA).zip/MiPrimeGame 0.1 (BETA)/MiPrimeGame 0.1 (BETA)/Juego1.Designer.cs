﻿namespace MiPrimeGame_0._1__BETA_
{
    partial class Juego1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            ListaDePistas1 = new ListBox();
            BotonEndGame1 = new Button();
            CajaJuego1 = new GroupBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            textBox220 = new TextBox();
            textBox221 = new TextBox();
            textBox222 = new TextBox();
            textBox223 = new TextBox();
            textBox202 = new TextBox();
            textBox203 = new TextBox();
            textBox204 = new TextBox();
            textBox205 = new TextBox();
            textBox206 = new TextBox();
            textBox207 = new TextBox();
            textBox208 = new TextBox();
            textBox209 = new TextBox();
            textBox211 = new TextBox();
            textBox184 = new TextBox();
            textBox185 = new TextBox();
            textBox186 = new TextBox();
            textBox187 = new TextBox();
            textBox188 = new TextBox();
            textBox189 = new TextBox();
            textBox190 = new TextBox();
            textBox169 = new TextBox();
            textBox171 = new TextBox();
            textBox172 = new TextBox();
            textBox173 = new TextBox();
            textBox174 = new TextBox();
            textBox151 = new TextBox();
            textBox152 = new TextBox();
            textBox153 = new TextBox();
            textBox154 = new TextBox();
            textBox155 = new TextBox();
            textBox156 = new TextBox();
            textBox157 = new TextBox();
            textBox158 = new TextBox();
            textBox161 = new TextBox();
            textBox162 = new TextBox();
            textBox163 = new TextBox();
            textBox164 = new TextBox();
            textBox165 = new TextBox();
            textBox136 = new TextBox();
            textBox137 = new TextBox();
            textBox138 = new TextBox();
            textBox139 = new TextBox();
            textBox140 = new TextBox();
            textBox141 = new TextBox();
            textBox142 = new TextBox();
            textBox143 = new TextBox();
            textBox144 = new TextBox();
            textBox145 = new TextBox();
            textBox146 = new TextBox();
            textBox147 = new TextBox();
            textBox148 = new TextBox();
            textBox149 = new TextBox();
            textBox121 = new TextBox();
            textBox122 = new TextBox();
            textBox123 = new TextBox();
            textBox124 = new TextBox();
            textBox125 = new TextBox();
            textBox126 = new TextBox();
            textBox127 = new TextBox();
            textBox130 = new TextBox();
            textBox131 = new TextBox();
            textBox132 = new TextBox();
            textBox133 = new TextBox();
            textBox109 = new TextBox();
            textBox110 = new TextBox();
            textBox111 = new TextBox();
            textBox112 = new TextBox();
            textBox113 = new TextBox();
            textBox114 = new TextBox();
            textBox115 = new TextBox();
            textBox116 = new TextBox();
            textBox117 = new TextBox();
            textBox93 = new TextBox();
            textBox94 = new TextBox();
            textBox95 = new TextBox();
            textBox96 = new TextBox();
            textBox97 = new TextBox();
            textBox98 = new TextBox();
            textBox99 = new TextBox();
            textBox100 = new TextBox();
            textBox101 = new TextBox();
            textBox102 = new TextBox();
            textBox103 = new TextBox();
            textBox104 = new TextBox();
            textBox105 = new TextBox();
            textBox78 = new TextBox();
            textBox79 = new TextBox();
            textBox80 = new TextBox();
            textBox81 = new TextBox();
            textBox82 = new TextBox();
            textBox83 = new TextBox();
            textBox84 = new TextBox();
            textBox86 = new TextBox();
            textBox87 = new TextBox();
            textBox61 = new TextBox();
            textBox62 = new TextBox();
            textBox63 = new TextBox();
            textBox64 = new TextBox();
            textBox65 = new TextBox();
            textBox66 = new TextBox();
            textBox68 = new TextBox();
            textBox69 = new TextBox();
            textBox70 = new TextBox();
            textBox71 = new TextBox();
            textBox72 = new TextBox();
            textBox73 = new TextBox();
            textBox74 = new TextBox();
            textBox48 = new TextBox();
            textBox50 = new TextBox();
            textBox53 = new TextBox();
            textBox54 = new TextBox();
            textBox55 = new TextBox();
            textBox56 = new TextBox();
            textBox57 = new TextBox();
            textBox31 = new TextBox();
            textBox32 = new TextBox();
            textBox33 = new TextBox();
            textBox34 = new TextBox();
            textBox35 = new TextBox();
            textBox36 = new TextBox();
            textBox40 = new TextBox();
            textBox41 = new TextBox();
            textBox42 = new TextBox();
            textBox18 = new TextBox();
            textBox26 = new TextBox();
            textBox27 = new TextBox();
            textBox5 = new TextBox();
            BotonRepe1 = new Button();
            NameCJ1 = new TextBox();
            TextBoxTiempoPG1 = new TextBox();
            TextBoxTiempoTG1 = new TextBox();
            TexTiempoPG1 = new Label();
            TexTiempoTG1 = new Label();
            label4 = new Label();
            label6 = new Label();
            ImagenCJ1 = new PictureBox();
            BotonPaTurno1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            PuntosJ1 = new TextBox();
            PuntosJ2 = new TextBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            listBox1 = new ListBox();
            timer1 = new System.Windows.Forms.Timer(components);
            BotonPausa = new Button();
            CajaJuego1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ImagenCJ1).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // ListaDePistas1
            // 
            ListaDePistas1.FormattingEnabled = true;
            ListaDePistas1.ItemHeight = 15;
            ListaDePistas1.Items.AddRange(new object[] { "// PALABRAS HORIZONTALES", "", "1.\tMas nerfeada que el cangrejo", "2.\tNo soy furro lo juro", "3.\tmmm...", "4.\tEl arbol Deku", "5.\tBi pero no", "6.\tEl legado de Shurima", "7.\tSabe a purpura", "8.\tMetal", "9.\tBananaaa", "10.\tSorieketon", "11.\tLa linterna", "12.\tPequeño demonio", "13.\tLos casafantasmas", "14.\t4444", "15.\tAlcanse infinito pa", "", "// PALABRAS VERTICALES", "", "1.\tIgnite y Velocidad", "2.\tTrampa de pasteles", "3.\tOK", "4.\tBolas de nieve", "5.\tAtrapa sueños", "6.\tSombras por aqui sombras por alla", "7.\tEl nombre de una gata", "8.\tNo paras de hablar?", "9.\tEl monjedel farol", "10.\tEl ciego de la jungla", "11.\tAdc en top >:(", "12.\tMarty MacFly", "13.\tPapa Pitufo", "14.\tEl herroro de volcanes", "15.\tMi finisimo caballero" });
            ListaDePistas1.Location = new Point(6, 5);
            ListaDePistas1.Name = "ListaDePistas1";
            ListaDePistas1.Size = new Size(210, 304);
            ListaDePistas1.TabIndex = 0;
            // 
            // BotonEndGame1
            // 
            BotonEndGame1.Location = new Point(673, 415);
            BotonEndGame1.Name = "BotonEndGame1";
            BotonEndGame1.Size = new Size(115, 23);
            BotonEndGame1.TabIndex = 2;
            BotonEndGame1.Text = "Finalizar Partida";
            BotonEndGame1.UseVisualStyleBackColor = true;
            BotonEndGame1.Click += BotonEndGame1_Click;
            // 
            // CajaJuego1
            // 
            CajaJuego1.Controls.Add(textBox4);
            CajaJuego1.Controls.Add(textBox3);
            CajaJuego1.Controls.Add(textBox2);
            CajaJuego1.Controls.Add(textBox1);
            CajaJuego1.Controls.Add(textBox220);
            CajaJuego1.Controls.Add(textBox221);
            CajaJuego1.Controls.Add(textBox222);
            CajaJuego1.Controls.Add(textBox223);
            CajaJuego1.Controls.Add(textBox202);
            CajaJuego1.Controls.Add(textBox203);
            CajaJuego1.Controls.Add(textBox204);
            CajaJuego1.Controls.Add(textBox205);
            CajaJuego1.Controls.Add(textBox206);
            CajaJuego1.Controls.Add(textBox207);
            CajaJuego1.Controls.Add(textBox208);
            CajaJuego1.Controls.Add(textBox209);
            CajaJuego1.Controls.Add(textBox211);
            CajaJuego1.Controls.Add(textBox184);
            CajaJuego1.Controls.Add(textBox185);
            CajaJuego1.Controls.Add(textBox186);
            CajaJuego1.Controls.Add(textBox187);
            CajaJuego1.Controls.Add(textBox188);
            CajaJuego1.Controls.Add(textBox189);
            CajaJuego1.Controls.Add(textBox190);
            CajaJuego1.Controls.Add(textBox169);
            CajaJuego1.Controls.Add(textBox171);
            CajaJuego1.Controls.Add(textBox172);
            CajaJuego1.Controls.Add(textBox173);
            CajaJuego1.Controls.Add(textBox174);
            CajaJuego1.Controls.Add(textBox151);
            CajaJuego1.Controls.Add(textBox152);
            CajaJuego1.Controls.Add(textBox153);
            CajaJuego1.Controls.Add(textBox154);
            CajaJuego1.Controls.Add(textBox155);
            CajaJuego1.Controls.Add(textBox156);
            CajaJuego1.Controls.Add(textBox157);
            CajaJuego1.Controls.Add(textBox158);
            CajaJuego1.Controls.Add(textBox161);
            CajaJuego1.Controls.Add(textBox162);
            CajaJuego1.Controls.Add(textBox163);
            CajaJuego1.Controls.Add(textBox164);
            CajaJuego1.Controls.Add(textBox165);
            CajaJuego1.Controls.Add(textBox136);
            CajaJuego1.Controls.Add(textBox137);
            CajaJuego1.Controls.Add(textBox138);
            CajaJuego1.Controls.Add(textBox139);
            CajaJuego1.Controls.Add(textBox140);
            CajaJuego1.Controls.Add(textBox141);
            CajaJuego1.Controls.Add(textBox142);
            CajaJuego1.Controls.Add(textBox143);
            CajaJuego1.Controls.Add(textBox144);
            CajaJuego1.Controls.Add(textBox145);
            CajaJuego1.Controls.Add(textBox146);
            CajaJuego1.Controls.Add(textBox147);
            CajaJuego1.Controls.Add(textBox148);
            CajaJuego1.Controls.Add(textBox149);
            CajaJuego1.Controls.Add(textBox121);
            CajaJuego1.Controls.Add(textBox122);
            CajaJuego1.Controls.Add(textBox123);
            CajaJuego1.Controls.Add(textBox124);
            CajaJuego1.Controls.Add(textBox125);
            CajaJuego1.Controls.Add(textBox126);
            CajaJuego1.Controls.Add(textBox127);
            CajaJuego1.Controls.Add(textBox130);
            CajaJuego1.Controls.Add(textBox131);
            CajaJuego1.Controls.Add(textBox132);
            CajaJuego1.Controls.Add(textBox133);
            CajaJuego1.Controls.Add(textBox109);
            CajaJuego1.Controls.Add(textBox110);
            CajaJuego1.Controls.Add(textBox111);
            CajaJuego1.Controls.Add(textBox112);
            CajaJuego1.Controls.Add(textBox113);
            CajaJuego1.Controls.Add(textBox114);
            CajaJuego1.Controls.Add(textBox115);
            CajaJuego1.Controls.Add(textBox116);
            CajaJuego1.Controls.Add(textBox117);
            CajaJuego1.Controls.Add(textBox93);
            CajaJuego1.Controls.Add(textBox94);
            CajaJuego1.Controls.Add(textBox95);
            CajaJuego1.Controls.Add(textBox96);
            CajaJuego1.Controls.Add(textBox97);
            CajaJuego1.Controls.Add(textBox98);
            CajaJuego1.Controls.Add(textBox99);
            CajaJuego1.Controls.Add(textBox100);
            CajaJuego1.Controls.Add(textBox101);
            CajaJuego1.Controls.Add(textBox102);
            CajaJuego1.Controls.Add(textBox103);
            CajaJuego1.Controls.Add(textBox104);
            CajaJuego1.Controls.Add(textBox105);
            CajaJuego1.Controls.Add(textBox78);
            CajaJuego1.Controls.Add(textBox79);
            CajaJuego1.Controls.Add(textBox80);
            CajaJuego1.Controls.Add(textBox81);
            CajaJuego1.Controls.Add(textBox82);
            CajaJuego1.Controls.Add(textBox83);
            CajaJuego1.Controls.Add(textBox84);
            CajaJuego1.Controls.Add(textBox86);
            CajaJuego1.Controls.Add(textBox87);
            CajaJuego1.Controls.Add(textBox61);
            CajaJuego1.Controls.Add(textBox62);
            CajaJuego1.Controls.Add(textBox63);
            CajaJuego1.Controls.Add(textBox64);
            CajaJuego1.Controls.Add(textBox65);
            CajaJuego1.Controls.Add(textBox66);
            CajaJuego1.Controls.Add(textBox68);
            CajaJuego1.Controls.Add(textBox69);
            CajaJuego1.Controls.Add(textBox70);
            CajaJuego1.Controls.Add(textBox71);
            CajaJuego1.Controls.Add(textBox72);
            CajaJuego1.Controls.Add(textBox73);
            CajaJuego1.Controls.Add(textBox74);
            CajaJuego1.Controls.Add(textBox48);
            CajaJuego1.Controls.Add(textBox50);
            CajaJuego1.Controls.Add(textBox53);
            CajaJuego1.Controls.Add(textBox54);
            CajaJuego1.Controls.Add(textBox55);
            CajaJuego1.Controls.Add(textBox56);
            CajaJuego1.Controls.Add(textBox57);
            CajaJuego1.Controls.Add(textBox31);
            CajaJuego1.Controls.Add(textBox32);
            CajaJuego1.Controls.Add(textBox33);
            CajaJuego1.Controls.Add(textBox34);
            CajaJuego1.Controls.Add(textBox35);
            CajaJuego1.Controls.Add(textBox36);
            CajaJuego1.Controls.Add(textBox40);
            CajaJuego1.Controls.Add(textBox41);
            CajaJuego1.Controls.Add(textBox42);
            CajaJuego1.Controls.Add(textBox18);
            CajaJuego1.Controls.Add(textBox26);
            CajaJuego1.Controls.Add(textBox27);
            CajaJuego1.Controls.Add(textBox5);
            CajaJuego1.Location = new Point(12, 12);
            CajaJuego1.Name = "CajaJuego1";
            CajaJuego1.Size = new Size(375, 394);
            CajaJuego1.TabIndex = 3;
            CajaJuego1.TabStop = false;
            CajaJuego1.Text = "League of Words (COMIENZA)";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(345, 147);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(18, 19);
            textBox4.TabIndex = 220;
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(345, 97);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(18, 19);
            textBox3.TabIndex = 219;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(345, 47);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(18, 19);
            textBox2.TabIndex = 218;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            textBox1.Enabled = false;
            textBox1.Location = new Point(345, 22);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(18, 19);
            textBox1.TabIndex = 217;
            textBox1.Text = "15.";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox220
            // 
            textBox220.Location = new Point(153, 372);
            textBox220.Multiline = true;
            textBox220.Name = "textBox220";
            textBox220.Size = new Size(18, 19);
            textBox220.TabIndex = 216;
            textBox220.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox221
            // 
            textBox221.Location = new Point(129, 372);
            textBox221.Multiline = true;
            textBox221.Name = "textBox221";
            textBox221.Size = new Size(18, 19);
            textBox221.TabIndex = 215;
            textBox221.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox222
            // 
            textBox222.Location = new Point(105, 372);
            textBox222.Multiline = true;
            textBox222.Name = "textBox222";
            textBox222.Size = new Size(18, 19);
            textBox222.TabIndex = 214;
            textBox222.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox223
            // 
            textBox223.Enabled = false;
            textBox223.Location = new Point(81, 372);
            textBox223.Multiline = true;
            textBox223.Name = "textBox223";
            textBox223.Size = new Size(18, 19);
            textBox223.TabIndex = 213;
            textBox223.Text = "9.";
            textBox223.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox202
            // 
            textBox202.Location = new Point(201, 347);
            textBox202.Multiline = true;
            textBox202.Name = "textBox202";
            textBox202.Size = new Size(18, 19);
            textBox202.TabIndex = 203;
            textBox202.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox203
            // 
            textBox203.Location = new Point(177, 347);
            textBox203.Multiline = true;
            textBox203.Name = "textBox203";
            textBox203.Size = new Size(18, 19);
            textBox203.TabIndex = 202;
            textBox203.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox204
            // 
            textBox204.Location = new Point(153, 347);
            textBox204.Multiline = true;
            textBox204.Name = "textBox204";
            textBox204.Size = new Size(18, 19);
            textBox204.TabIndex = 201;
            textBox204.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox205
            // 
            textBox205.Location = new Point(129, 347);
            textBox205.Multiline = true;
            textBox205.Name = "textBox205";
            textBox205.Size = new Size(18, 19);
            textBox205.TabIndex = 200;
            textBox205.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox206
            // 
            textBox206.Location = new Point(105, 347);
            textBox206.Multiline = true;
            textBox206.Name = "textBox206";
            textBox206.Size = new Size(18, 19);
            textBox206.TabIndex = 199;
            textBox206.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox207
            // 
            textBox207.Location = new Point(81, 347);
            textBox207.Multiline = true;
            textBox207.Name = "textBox207";
            textBox207.Size = new Size(18, 19);
            textBox207.TabIndex = 198;
            textBox207.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox208
            // 
            textBox208.Location = new Point(57, 347);
            textBox208.Multiline = true;
            textBox208.Name = "textBox208";
            textBox208.Size = new Size(18, 19);
            textBox208.TabIndex = 197;
            textBox208.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox209
            // 
            textBox209.Location = new Point(33, 347);
            textBox209.Multiline = true;
            textBox209.Name = "textBox209";
            textBox209.Size = new Size(18, 19);
            textBox209.TabIndex = 196;
            textBox209.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox211
            // 
            textBox211.Enabled = false;
            textBox211.Location = new Point(9, 347);
            textBox211.Multiline = true;
            textBox211.Name = "textBox211";
            textBox211.Size = new Size(18, 19);
            textBox211.TabIndex = 195;
            textBox211.Text = "7.";
            textBox211.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox184
            // 
            textBox184.Location = new Point(273, 322);
            textBox184.Multiline = true;
            textBox184.Name = "textBox184";
            textBox184.Size = new Size(18, 19);
            textBox184.TabIndex = 191;
            textBox184.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox185
            // 
            textBox185.Location = new Point(249, 322);
            textBox185.Multiline = true;
            textBox185.Name = "textBox185";
            textBox185.Size = new Size(18, 19);
            textBox185.TabIndex = 190;
            textBox185.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox186
            // 
            textBox186.Location = new Point(225, 322);
            textBox186.Multiline = true;
            textBox186.Name = "textBox186";
            textBox186.Size = new Size(18, 19);
            textBox186.TabIndex = 189;
            textBox186.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox187
            // 
            textBox187.Location = new Point(201, 322);
            textBox187.Multiline = true;
            textBox187.Name = "textBox187";
            textBox187.Size = new Size(18, 19);
            textBox187.TabIndex = 188;
            textBox187.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox188
            // 
            textBox188.Location = new Point(177, 322);
            textBox188.Multiline = true;
            textBox188.Name = "textBox188";
            textBox188.Size = new Size(18, 19);
            textBox188.TabIndex = 187;
            textBox188.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox189
            // 
            textBox189.Location = new Point(153, 322);
            textBox189.Multiline = true;
            textBox189.Name = "textBox189";
            textBox189.Size = new Size(18, 19);
            textBox189.TabIndex = 186;
            textBox189.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox190
            // 
            textBox190.Enabled = false;
            textBox190.Location = new Point(129, 322);
            textBox190.Multiline = true;
            textBox190.Name = "textBox190";
            textBox190.Size = new Size(18, 19);
            textBox190.TabIndex = 185;
            textBox190.Text = "5.";
            textBox190.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox169
            // 
            textBox169.Location = new Point(273, 297);
            textBox169.Multiline = true;
            textBox169.Name = "textBox169";
            textBox169.Size = new Size(18, 19);
            textBox169.TabIndex = 176;
            textBox169.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox171
            // 
            textBox171.Location = new Point(225, 297);
            textBox171.Multiline = true;
            textBox171.Name = "textBox171";
            textBox171.Size = new Size(18, 19);
            textBox171.TabIndex = 174;
            textBox171.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox172
            // 
            textBox172.Location = new Point(201, 297);
            textBox172.Multiline = true;
            textBox172.Name = "textBox172";
            textBox172.Size = new Size(18, 19);
            textBox172.TabIndex = 173;
            textBox172.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox173
            // 
            textBox173.Location = new Point(177, 297);
            textBox173.Multiline = true;
            textBox173.Name = "textBox173";
            textBox173.Size = new Size(18, 19);
            textBox173.TabIndex = 172;
            textBox173.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox174
            // 
            textBox174.Enabled = false;
            textBox174.Location = new Point(153, 297);
            textBox174.Multiline = true;
            textBox174.Name = "textBox174";
            textBox174.Size = new Size(18, 19);
            textBox174.TabIndex = 171;
            textBox174.Text = "11.";
            textBox174.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox151
            // 
            textBox151.Location = new Point(345, 272);
            textBox151.Multiline = true;
            textBox151.Name = "textBox151";
            textBox151.Size = new Size(18, 19);
            textBox151.TabIndex = 164;
            textBox151.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox152
            // 
            textBox152.Location = new Point(321, 272);
            textBox152.Multiline = true;
            textBox152.Name = "textBox152";
            textBox152.Size = new Size(18, 19);
            textBox152.TabIndex = 163;
            textBox152.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox153
            // 
            textBox153.Location = new Point(297, 272);
            textBox153.Multiline = true;
            textBox153.Name = "textBox153";
            textBox153.Size = new Size(18, 19);
            textBox153.TabIndex = 162;
            textBox153.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox154
            // 
            textBox154.Location = new Point(273, 272);
            textBox154.Multiline = true;
            textBox154.Name = "textBox154";
            textBox154.Size = new Size(18, 19);
            textBox154.TabIndex = 161;
            textBox154.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox155
            // 
            textBox155.Enabled = false;
            textBox155.Location = new Point(249, 272);
            textBox155.Multiline = true;
            textBox155.Name = "textBox155";
            textBox155.Size = new Size(18, 19);
            textBox155.TabIndex = 160;
            textBox155.Text = "8.";
            textBox155.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox156
            // 
            textBox156.Location = new Point(225, 272);
            textBox156.Multiline = true;
            textBox156.Name = "textBox156";
            textBox156.Size = new Size(18, 19);
            textBox156.TabIndex = 159;
            textBox156.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox157
            // 
            textBox157.Location = new Point(201, 272);
            textBox157.Multiline = true;
            textBox157.Name = "textBox157";
            textBox157.Size = new Size(18, 19);
            textBox157.TabIndex = 158;
            textBox157.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox158
            // 
            textBox158.Location = new Point(177, 272);
            textBox158.Multiline = true;
            textBox158.Name = "textBox158";
            textBox158.Size = new Size(18, 19);
            textBox158.TabIndex = 157;
            textBox158.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox161
            // 
            textBox161.Location = new Point(105, 272);
            textBox161.Multiline = true;
            textBox161.Name = "textBox161";
            textBox161.Size = new Size(18, 19);
            textBox161.TabIndex = 154;
            textBox161.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox162
            // 
            textBox162.Location = new Point(81, 272);
            textBox162.Multiline = true;
            textBox162.Name = "textBox162";
            textBox162.Size = new Size(18, 19);
            textBox162.TabIndex = 153;
            textBox162.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox163
            // 
            textBox163.Location = new Point(57, 272);
            textBox163.Multiline = true;
            textBox163.Name = "textBox163";
            textBox163.Size = new Size(18, 19);
            textBox163.TabIndex = 152;
            textBox163.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox164
            // 
            textBox164.Location = new Point(33, 272);
            textBox164.Multiline = true;
            textBox164.Name = "textBox164";
            textBox164.Size = new Size(18, 19);
            textBox164.TabIndex = 151;
            textBox164.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox165
            // 
            textBox165.Enabled = false;
            textBox165.Location = new Point(9, 272);
            textBox165.Multiline = true;
            textBox165.Name = "textBox165";
            textBox165.Size = new Size(18, 19);
            textBox165.TabIndex = 150;
            textBox165.Text = "12.";
            textBox165.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox136
            // 
            textBox136.Location = new Point(345, 247);
            textBox136.Multiline = true;
            textBox136.Name = "textBox136";
            textBox136.Size = new Size(18, 19);
            textBox136.TabIndex = 149;
            textBox136.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox137
            // 
            textBox137.Location = new Point(321, 247);
            textBox137.Multiline = true;
            textBox137.Name = "textBox137";
            textBox137.Size = new Size(18, 19);
            textBox137.TabIndex = 148;
            textBox137.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox138
            // 
            textBox138.Location = new Point(297, 247);
            textBox138.Multiline = true;
            textBox138.Name = "textBox138";
            textBox138.Size = new Size(18, 19);
            textBox138.TabIndex = 147;
            textBox138.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox139
            // 
            textBox139.Location = new Point(273, 247);
            textBox139.Multiline = true;
            textBox139.Name = "textBox139";
            textBox139.Size = new Size(18, 19);
            textBox139.TabIndex = 146;
            textBox139.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox140
            // 
            textBox140.Enabled = false;
            textBox140.Location = new Point(249, 247);
            textBox140.Multiline = true;
            textBox140.Name = "textBox140";
            textBox140.Size = new Size(18, 19);
            textBox140.TabIndex = 145;
            textBox140.Text = "13.";
            textBox140.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox141
            // 
            textBox141.Location = new Point(225, 247);
            textBox141.Multiline = true;
            textBox141.Name = "textBox141";
            textBox141.Size = new Size(18, 19);
            textBox141.TabIndex = 144;
            textBox141.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox142
            // 
            textBox142.Location = new Point(201, 247);
            textBox142.Multiline = true;
            textBox142.Name = "textBox142";
            textBox142.Size = new Size(18, 19);
            textBox142.TabIndex = 143;
            textBox142.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox143
            // 
            textBox143.Enabled = false;
            textBox143.Location = new Point(177, 247);
            textBox143.Multiline = true;
            textBox143.Name = "textBox143";
            textBox143.Size = new Size(18, 19);
            textBox143.TabIndex = 142;
            textBox143.Text = "14.";
            textBox143.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox144
            // 
            textBox144.Location = new Point(153, 247);
            textBox144.Multiline = true;
            textBox144.Name = "textBox144";
            textBox144.Size = new Size(18, 19);
            textBox144.TabIndex = 141;
            textBox144.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox145
            // 
            textBox145.Location = new Point(129, 247);
            textBox145.Multiline = true;
            textBox145.Name = "textBox145";
            textBox145.Size = new Size(18, 19);
            textBox145.TabIndex = 140;
            textBox145.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox146
            // 
            textBox146.Location = new Point(105, 247);
            textBox146.Multiline = true;
            textBox146.Name = "textBox146";
            textBox146.Size = new Size(18, 19);
            textBox146.TabIndex = 139;
            textBox146.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox147
            // 
            textBox147.Location = new Point(81, 247);
            textBox147.Multiline = true;
            textBox147.Name = "textBox147";
            textBox147.Size = new Size(18, 19);
            textBox147.TabIndex = 138;
            textBox147.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox148
            // 
            textBox148.Location = new Point(57, 247);
            textBox148.Multiline = true;
            textBox148.Name = "textBox148";
            textBox148.Size = new Size(18, 19);
            textBox148.TabIndex = 137;
            textBox148.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox149
            // 
            textBox149.Enabled = false;
            textBox149.Location = new Point(33, 247);
            textBox149.Multiline = true;
            textBox149.Name = "textBox149";
            textBox149.Size = new Size(18, 19);
            textBox149.TabIndex = 136;
            textBox149.Text = "15.";
            textBox149.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox121
            // 
            textBox121.Location = new Point(345, 222);
            textBox121.Multiline = true;
            textBox121.Name = "textBox121";
            textBox121.Size = new Size(18, 19);
            textBox121.TabIndex = 134;
            textBox121.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox122
            // 
            textBox122.Location = new Point(321, 222);
            textBox122.Multiline = true;
            textBox122.Name = "textBox122";
            textBox122.Size = new Size(18, 19);
            textBox122.TabIndex = 133;
            textBox122.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox123
            // 
            textBox123.Location = new Point(297, 222);
            textBox123.Multiline = true;
            textBox123.Name = "textBox123";
            textBox123.Size = new Size(18, 19);
            textBox123.TabIndex = 132;
            textBox123.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox124
            // 
            textBox124.Location = new Point(273, 222);
            textBox124.Multiline = true;
            textBox124.Name = "textBox124";
            textBox124.Size = new Size(18, 19);
            textBox124.TabIndex = 131;
            textBox124.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox125
            // 
            textBox125.Enabled = false;
            textBox125.Location = new Point(249, 222);
            textBox125.Multiline = true;
            textBox125.Name = "textBox125";
            textBox125.Size = new Size(18, 19);
            textBox125.TabIndex = 130;
            textBox125.Text = "14.";
            textBox125.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox126
            // 
            textBox126.Location = new Point(225, 222);
            textBox126.Multiline = true;
            textBox126.Name = "textBox126";
            textBox126.Size = new Size(18, 19);
            textBox126.TabIndex = 129;
            textBox126.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox127
            // 
            textBox127.Location = new Point(201, 222);
            textBox127.Multiline = true;
            textBox127.Name = "textBox127";
            textBox127.Size = new Size(18, 19);
            textBox127.TabIndex = 128;
            textBox127.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox130
            // 
            textBox130.Location = new Point(129, 222);
            textBox130.Multiline = true;
            textBox130.Name = "textBox130";
            textBox130.Size = new Size(18, 19);
            textBox130.TabIndex = 125;
            textBox130.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox131
            // 
            textBox131.Location = new Point(105, 222);
            textBox131.Multiline = true;
            textBox131.Name = "textBox131";
            textBox131.Size = new Size(18, 19);
            textBox131.TabIndex = 124;
            textBox131.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox132
            // 
            textBox132.Location = new Point(81, 222);
            textBox132.Multiline = true;
            textBox132.Name = "textBox132";
            textBox132.Size = new Size(18, 19);
            textBox132.TabIndex = 123;
            textBox132.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox133
            // 
            textBox133.Enabled = false;
            textBox133.Location = new Point(57, 222);
            textBox133.Multiline = true;
            textBox133.Name = "textBox133";
            textBox133.Size = new Size(18, 19);
            textBox133.TabIndex = 122;
            textBox133.Text = "6.";
            textBox133.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox109
            // 
            textBox109.Location = new Point(273, 197);
            textBox109.Multiline = true;
            textBox109.Name = "textBox109";
            textBox109.Size = new Size(18, 19);
            textBox109.TabIndex = 116;
            textBox109.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox110
            // 
            textBox110.Location = new Point(249, 197);
            textBox110.Multiline = true;
            textBox110.Name = "textBox110";
            textBox110.Size = new Size(18, 19);
            textBox110.TabIndex = 115;
            textBox110.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox111
            // 
            textBox111.Location = new Point(225, 197);
            textBox111.Multiline = true;
            textBox111.Name = "textBox111";
            textBox111.Size = new Size(18, 19);
            textBox111.TabIndex = 114;
            textBox111.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox112
            // 
            textBox112.Location = new Point(201, 197);
            textBox112.Multiline = true;
            textBox112.Name = "textBox112";
            textBox112.Size = new Size(18, 19);
            textBox112.TabIndex = 113;
            textBox112.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox113
            // 
            textBox113.Location = new Point(177, 197);
            textBox113.Multiline = true;
            textBox113.Name = "textBox113";
            textBox113.Size = new Size(18, 19);
            textBox113.TabIndex = 112;
            textBox113.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox114
            // 
            textBox114.Location = new Point(153, 197);
            textBox114.Multiline = true;
            textBox114.Name = "textBox114";
            textBox114.Size = new Size(18, 19);
            textBox114.TabIndex = 111;
            textBox114.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox115
            // 
            textBox115.Enabled = false;
            textBox115.Location = new Point(129, 197);
            textBox115.Multiline = true;
            textBox115.Name = "textBox115";
            textBox115.Size = new Size(18, 19);
            textBox115.TabIndex = 110;
            textBox115.Text = "3.";
            textBox115.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox116
            // 
            textBox116.Location = new Point(105, 197);
            textBox116.Multiline = true;
            textBox116.Name = "textBox116";
            textBox116.Size = new Size(18, 19);
            textBox116.TabIndex = 109;
            textBox116.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox117
            // 
            textBox117.Enabled = false;
            textBox117.Location = new Point(81, 197);
            textBox117.Multiline = true;
            textBox117.Name = "textBox117";
            textBox117.Size = new Size(18, 19);
            textBox117.TabIndex = 108;
            textBox117.Text = "13.";
            textBox117.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox93
            // 
            textBox93.Location = new Point(297, 172);
            textBox93.Multiline = true;
            textBox93.Name = "textBox93";
            textBox93.Size = new Size(18, 19);
            textBox93.TabIndex = 102;
            textBox93.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox94
            // 
            textBox94.Enabled = false;
            textBox94.Location = new Point(273, 172);
            textBox94.Multiline = true;
            textBox94.Name = "textBox94";
            textBox94.Size = new Size(18, 19);
            textBox94.TabIndex = 101;
            textBox94.Text = "9.";
            textBox94.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox95
            // 
            textBox95.Location = new Point(249, 172);
            textBox95.Multiline = true;
            textBox95.Name = "textBox95";
            textBox95.Size = new Size(18, 19);
            textBox95.TabIndex = 100;
            textBox95.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox96
            // 
            textBox96.Enabled = false;
            textBox96.Location = new Point(225, 172);
            textBox96.Multiline = true;
            textBox96.Name = "textBox96";
            textBox96.Size = new Size(18, 19);
            textBox96.TabIndex = 99;
            textBox96.Text = "4.";
            textBox96.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox97
            // 
            textBox97.Enabled = false;
            textBox97.Location = new Point(201, 172);
            textBox97.Multiline = true;
            textBox97.Name = "textBox97";
            textBox97.Size = new Size(18, 19);
            textBox97.TabIndex = 98;
            textBox97.Text = "8.";
            textBox97.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox98
            // 
            textBox98.Location = new Point(177, 172);
            textBox98.Multiline = true;
            textBox98.Name = "textBox98";
            textBox98.Size = new Size(18, 19);
            textBox98.TabIndex = 97;
            textBox98.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox99
            // 
            textBox99.Location = new Point(153, 172);
            textBox99.Multiline = true;
            textBox99.Name = "textBox99";
            textBox99.Size = new Size(18, 19);
            textBox99.TabIndex = 96;
            textBox99.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox100
            // 
            textBox100.Location = new Point(129, 172);
            textBox100.Multiline = true;
            textBox100.Name = "textBox100";
            textBox100.Size = new Size(18, 19);
            textBox100.TabIndex = 95;
            textBox100.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox101
            // 
            textBox101.Location = new Point(105, 172);
            textBox101.Multiline = true;
            textBox101.Name = "textBox101";
            textBox101.Size = new Size(18, 19);
            textBox101.TabIndex = 94;
            textBox101.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox102
            // 
            textBox102.Location = new Point(81, 172);
            textBox102.Multiline = true;
            textBox102.Name = "textBox102";
            textBox102.Size = new Size(18, 19);
            textBox102.TabIndex = 93;
            textBox102.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox103
            // 
            textBox103.Location = new Point(57, 172);
            textBox103.Multiline = true;
            textBox103.Name = "textBox103";
            textBox103.Size = new Size(18, 19);
            textBox103.TabIndex = 92;
            textBox103.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox104
            // 
            textBox104.Location = new Point(33, 172);
            textBox104.Multiline = true;
            textBox104.Name = "textBox104";
            textBox104.Size = new Size(18, 19);
            textBox104.TabIndex = 91;
            textBox104.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox105
            // 
            textBox105.Enabled = false;
            textBox105.Location = new Point(9, 172);
            textBox105.Multiline = true;
            textBox105.Name = "textBox105";
            textBox105.Size = new Size(18, 19);
            textBox105.TabIndex = 90;
            textBox105.Text = "2.";
            textBox105.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox78
            // 
            textBox78.Location = new Point(297, 147);
            textBox78.Multiline = true;
            textBox78.Name = "textBox78";
            textBox78.Size = new Size(18, 19);
            textBox78.TabIndex = 87;
            textBox78.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox79
            // 
            textBox79.Location = new Point(273, 147);
            textBox79.Multiline = true;
            textBox79.Name = "textBox79";
            textBox79.Size = new Size(18, 19);
            textBox79.TabIndex = 86;
            textBox79.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox80
            // 
            textBox80.Location = new Point(249, 147);
            textBox80.Multiline = true;
            textBox80.Name = "textBox80";
            textBox80.Size = new Size(18, 19);
            textBox80.TabIndex = 85;
            textBox80.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox81
            // 
            textBox81.Location = new Point(225, 147);
            textBox81.Multiline = true;
            textBox81.Name = "textBox81";
            textBox81.Size = new Size(18, 19);
            textBox81.TabIndex = 84;
            textBox81.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox82
            // 
            textBox82.Enabled = false;
            textBox82.Location = new Point(201, 147);
            textBox82.Multiline = true;
            textBox82.Name = "textBox82";
            textBox82.Size = new Size(18, 19);
            textBox82.TabIndex = 83;
            textBox82.Text = "4.";
            textBox82.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox83
            // 
            textBox83.Location = new Point(177, 147);
            textBox83.Multiline = true;
            textBox83.Name = "textBox83";
            textBox83.Size = new Size(18, 19);
            textBox83.TabIndex = 82;
            textBox83.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox84
            // 
            textBox84.Location = new Point(153, 147);
            textBox84.Multiline = true;
            textBox84.Name = "textBox84";
            textBox84.Size = new Size(18, 19);
            textBox84.TabIndex = 81;
            textBox84.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox86
            // 
            textBox86.Enabled = false;
            textBox86.Location = new Point(105, 147);
            textBox86.Multiline = true;
            textBox86.Name = "textBox86";
            textBox86.Size = new Size(18, 19);
            textBox86.TabIndex = 79;
            textBox86.Text = "12.";
            textBox86.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox87
            // 
            textBox87.Location = new Point(81, 147);
            textBox87.Multiline = true;
            textBox87.Name = "textBox87";
            textBox87.Size = new Size(18, 19);
            textBox87.TabIndex = 78;
            textBox87.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox61
            // 
            textBox61.Location = new Point(345, 122);
            textBox61.Multiline = true;
            textBox61.Name = "textBox61";
            textBox61.Size = new Size(18, 19);
            textBox61.TabIndex = 74;
            textBox61.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox62
            // 
            textBox62.Location = new Point(321, 122);
            textBox62.Multiline = true;
            textBox62.Name = "textBox62";
            textBox62.Size = new Size(18, 19);
            textBox62.TabIndex = 73;
            textBox62.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            textBox63.Location = new Point(297, 122);
            textBox63.Multiline = true;
            textBox63.Name = "textBox63";
            textBox63.Size = new Size(18, 19);
            textBox63.TabIndex = 72;
            textBox63.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox64
            // 
            textBox64.Location = new Point(273, 122);
            textBox64.Multiline = true;
            textBox64.Name = "textBox64";
            textBox64.Size = new Size(18, 19);
            textBox64.TabIndex = 71;
            textBox64.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox65
            // 
            textBox65.Location = new Point(249, 122);
            textBox65.Multiline = true;
            textBox65.Name = "textBox65";
            textBox65.Size = new Size(18, 19);
            textBox65.TabIndex = 70;
            textBox65.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox66
            // 
            textBox66.Enabled = false;
            textBox66.Location = new Point(225, 122);
            textBox66.Multiline = true;
            textBox66.Name = "textBox66";
            textBox66.Size = new Size(18, 19);
            textBox66.TabIndex = 69;
            textBox66.Text = "10.";
            textBox66.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox68
            // 
            textBox68.Location = new Point(177, 122);
            textBox68.Multiline = true;
            textBox68.Name = "textBox68";
            textBox68.Size = new Size(18, 19);
            textBox68.TabIndex = 67;
            textBox68.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox69
            // 
            textBox69.Location = new Point(153, 122);
            textBox69.Multiline = true;
            textBox69.Name = "textBox69";
            textBox69.Size = new Size(18, 19);
            textBox69.TabIndex = 66;
            textBox69.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox70
            // 
            textBox70.Location = new Point(129, 122);
            textBox70.Multiline = true;
            textBox70.Name = "textBox70";
            textBox70.Size = new Size(18, 19);
            textBox70.TabIndex = 65;
            textBox70.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox71
            // 
            textBox71.Location = new Point(105, 122);
            textBox71.Multiline = true;
            textBox71.Name = "textBox71";
            textBox71.Size = new Size(18, 19);
            textBox71.TabIndex = 64;
            textBox71.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox72
            // 
            textBox72.Location = new Point(81, 122);
            textBox72.Multiline = true;
            textBox72.Name = "textBox72";
            textBox72.Size = new Size(18, 19);
            textBox72.TabIndex = 63;
            textBox72.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox73
            // 
            textBox73.Location = new Point(57, 122);
            textBox73.Multiline = true;
            textBox73.Name = "textBox73";
            textBox73.Size = new Size(18, 19);
            textBox73.TabIndex = 62;
            textBox73.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox74
            // 
            textBox74.Enabled = false;
            textBox74.Location = new Point(33, 122);
            textBox74.Multiline = true;
            textBox74.Name = "textBox74";
            textBox74.Size = new Size(18, 19);
            textBox74.TabIndex = 61;
            textBox74.Text = "1.";
            textBox74.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox48
            // 
            textBox48.Location = new Point(297, 97);
            textBox48.Multiline = true;
            textBox48.Name = "textBox48";
            textBox48.Size = new Size(18, 19);
            textBox48.TabIndex = 57;
            textBox48.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox50
            // 
            textBox50.Enabled = false;
            textBox50.Location = new Point(249, 97);
            textBox50.Multiline = true;
            textBox50.Name = "textBox50";
            textBox50.Size = new Size(18, 19);
            textBox50.TabIndex = 55;
            textBox50.Text = "7.";
            textBox50.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox53
            // 
            textBox53.Enabled = false;
            textBox53.Location = new Point(177, 97);
            textBox53.Multiline = true;
            textBox53.Name = "textBox53";
            textBox53.Size = new Size(18, 19);
            textBox53.TabIndex = 52;
            textBox53.Text = "3.";
            textBox53.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox54
            // 
            textBox54.Enabled = false;
            textBox54.Location = new Point(153, 97);
            textBox54.Multiline = true;
            textBox54.Name = "textBox54";
            textBox54.Size = new Size(18, 19);
            textBox54.TabIndex = 51;
            textBox54.Text = "2.";
            textBox54.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox55
            // 
            textBox55.Location = new Point(129, 97);
            textBox55.Multiline = true;
            textBox55.Name = "textBox55";
            textBox55.Size = new Size(18, 19);
            textBox55.TabIndex = 50;
            textBox55.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            textBox56.Location = new Point(105, 97);
            textBox56.Multiline = true;
            textBox56.Name = "textBox56";
            textBox56.Size = new Size(18, 19);
            textBox56.TabIndex = 49;
            textBox56.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            textBox57.Location = new Point(81, 97);
            textBox57.Multiline = true;
            textBox57.Name = "textBox57";
            textBox57.Size = new Size(18, 19);
            textBox57.TabIndex = 48;
            textBox57.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            textBox31.Location = new Point(345, 72);
            textBox31.Multiline = true;
            textBox31.Name = "textBox31";
            textBox31.Size = new Size(18, 19);
            textBox31.TabIndex = 44;
            textBox31.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            textBox32.Location = new Point(321, 72);
            textBox32.Multiline = true;
            textBox32.Name = "textBox32";
            textBox32.Size = new Size(18, 19);
            textBox32.TabIndex = 43;
            textBox32.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            textBox33.Location = new Point(297, 72);
            textBox33.Multiline = true;
            textBox33.Name = "textBox33";
            textBox33.Size = new Size(18, 19);
            textBox33.TabIndex = 42;
            textBox33.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            textBox34.Location = new Point(273, 72);
            textBox34.Multiline = true;
            textBox34.Name = "textBox34";
            textBox34.Size = new Size(18, 19);
            textBox34.TabIndex = 41;
            textBox34.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            textBox35.Location = new Point(249, 72);
            textBox35.Multiline = true;
            textBox35.Name = "textBox35";
            textBox35.Size = new Size(18, 19);
            textBox35.TabIndex = 40;
            textBox35.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            textBox36.Enabled = false;
            textBox36.Location = new Point(225, 72);
            textBox36.Multiline = true;
            textBox36.Name = "textBox36";
            textBox36.Size = new Size(18, 19);
            textBox36.TabIndex = 39;
            textBox36.Text = "11.";
            textBox36.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            textBox40.Enabled = false;
            textBox40.Location = new Point(129, 72);
            textBox40.Multiline = true;
            textBox40.Name = "textBox40";
            textBox40.Size = new Size(18, 19);
            textBox40.TabIndex = 35;
            textBox40.Text = "5.";
            textBox40.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            textBox41.Location = new Point(105, 72);
            textBox41.Multiline = true;
            textBox41.Name = "textBox41";
            textBox41.Size = new Size(18, 19);
            textBox41.TabIndex = 34;
            textBox41.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            textBox42.Location = new Point(81, 72);
            textBox42.Multiline = true;
            textBox42.Name = "textBox42";
            textBox42.Size = new Size(18, 19);
            textBox42.TabIndex = 33;
            textBox42.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            textBox18.Enabled = false;
            textBox18.Location = new Point(297, 47);
            textBox18.Multiline = true;
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(18, 19);
            textBox18.TabIndex = 27;
            textBox18.Text = "10.";
            textBox18.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            textBox26.Location = new Point(105, 47);
            textBox26.Multiline = true;
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(18, 19);
            textBox26.TabIndex = 19;
            textBox26.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            textBox27.Enabled = false;
            textBox27.Location = new Point(81, 47);
            textBox27.Multiline = true;
            textBox27.Name = "textBox27";
            textBox27.Size = new Size(18, 19);
            textBox27.TabIndex = 18;
            textBox27.Text = "1.";
            textBox27.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            textBox5.Enabled = false;
            textBox5.Location = new Point(105, 22);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(18, 19);
            textBox5.TabIndex = 4;
            textBox5.Text = "6.";
            textBox5.TextAlign = HorizontalAlignment.Center;
            // 
            // BotonRepe1
            // 
            BotonRepe1.Location = new Point(553, 415);
            BotonRepe1.Name = "BotonRepe1";
            BotonRepe1.Size = new Size(114, 23);
            BotonRepe1.TabIndex = 4;
            BotonRepe1.Text = "Reiniciar Partida";
            BotonRepe1.UseVisualStyleBackColor = true;
            BotonRepe1.Click += BotonRepe1_Click;
            // 
            // NameCJ1
            // 
            NameCJ1.Enabled = false;
            NameCJ1.Location = new Point(420, 165);
            NameCJ1.Name = "NameCJ1";
            NameCJ1.Size = new Size(103, 23);
            NameCJ1.TabIndex = 6;
            NameCJ1.TextAlign = HorizontalAlignment.Center;
            // 
            // TextBoxTiempoPG1
            // 
            TextBoxTiempoPG1.Enabled = false;
            TextBoxTiempoPG1.Location = new Point(130, 416);
            TextBoxTiempoPG1.Name = "TextBoxTiempoPG1";
            TextBoxTiempoPG1.Size = new Size(115, 23);
            TextBoxTiempoPG1.TabIndex = 8;
            // 
            // TextBoxTiempoTG1
            // 
            TextBoxTiempoTG1.Enabled = false;
            TextBoxTiempoTG1.Location = new Point(371, 415);
            TextBoxTiempoTG1.Name = "TextBoxTiempoTG1";
            TextBoxTiempoTG1.Size = new Size(115, 23);
            TextBoxTiempoTG1.TabIndex = 9;
            // 
            // TexTiempoPG1
            // 
            TexTiempoPG1.AutoSize = true;
            TexTiempoPG1.Location = new Point(12, 419);
            TexTiempoPG1.Name = "TexTiempoPG1";
            TexTiempoPG1.Size = new Size(112, 15);
            TexTiempoPG1.TabIndex = 10;
            TexTiempoPG1.Text = "Tiempo de partida : ";
            // 
            // TexTiempoTG1
            // 
            TexTiempoTG1.AutoSize = true;
            TexTiempoTG1.Location = new Point(251, 419);
            TexTiempoTG1.Name = "TexTiempoTG1";
            TexTiempoTG1.Size = new Size(114, 15);
            TexTiempoTG1.TabIndex = 11;
            TexTiempoTG1.Text = "Tiempo por turnos : ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(555, 327);
            label4.Name = "label4";
            label4.Size = new Size(0, 15);
            label4.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(555, 394);
            label6.Name = "label6";
            label6.Size = new Size(0, 15);
            label6.TabIndex = 18;
            // 
            // ImagenCJ1
            // 
            ImagenCJ1.Location = new Point(409, 41);
            ImagenCJ1.Name = "ImagenCJ1";
            ImagenCJ1.Size = new Size(124, 118);
            ImagenCJ1.SizeMode = PictureBoxSizeMode.Zoom;
            ImagenCJ1.TabIndex = 29;
            ImagenCJ1.TabStop = false;
            ImagenCJ1.Click += ImagenCJ1_Click;
            // 
            // BotonPaTurno1
            // 
            BotonPaTurno1.Location = new Point(420, 194);
            BotonPaTurno1.Name = "BotonPaTurno1";
            BotonPaTurno1.Size = new Size(103, 23);
            BotonPaTurno1.TabIndex = 31;
            BotonPaTurno1.Text = "Completado";
            BotonPaTurno1.UseVisualStyleBackColor = true;
            BotonPaTurno1.Click += BotonPaTurno1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(614, 359);
            label1.Name = "label1";
            label1.Size = new Size(120, 15);
            label1.TabIndex = 0;
            label1.Text = "Marcador de puntos :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(555, 389);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 32;
            label2.Text = "Jugador 1 :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(676, 389);
            label3.Name = "label3";
            label3.Size = new Size(67, 15);
            label3.TabIndex = 33;
            label3.Text = "Jugador 2 : ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(439, 23);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 34;
            label5.Text = "Turno de : ";
            // 
            // PuntosJ1
            // 
            PuntosJ1.Enabled = false;
            PuntosJ1.Location = new Point(619, 386);
            PuntosJ1.Name = "PuntosJ1";
            PuntosJ1.Size = new Size(48, 23);
            PuntosJ1.TabIndex = 35;
            // 
            // PuntosJ2
            // 
            PuntosJ2.Enabled = false;
            PuntosJ2.Location = new Point(740, 386);
            PuntosJ2.Name = "PuntosJ2";
            PuntosJ2.Size = new Size(48, 23);
            PuntosJ2.TabIndex = 36;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(555, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(230, 344);
            tabControl1.TabIndex = 37;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(ListaDePistas1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(222, 316);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Preguntas";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(listBox1);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(222, 316);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Respuestas";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Items.AddRange(new object[] { "// PALABRAS HORIZONTALES", "", "1.\tAKALI", "2.\tUDIR", "3.\tSONA", "4.\tMAOKAL", "5.\tVI", "6.\tAZIR", "7.\tLULU", "8.\tMORDE", "9.\tSORAKA", "10.\tYASUO", "11.\tLUX", "12.\tTEEMO", "13.\tZAK", "14.\tJHIN", "15.\tSENNA", "", "// PALABRAS VERTICALES", "", "1.\tDARIUS", "2.\tCAITLYN", "3.\tRAMMUS", "4.\tNUNU", "5.\tLILLIA", "6.\tZED", "7.\tMFORTUNE", "8.\tASHE", "9.\tJAX", "10.\tLESIN", "11.\tVAYNE", "12.\tEKKO", "13.\tRYZE", "14.\tORNN", "15.\tTAMKE" });
            listBox1.Location = new Point(6, 6);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(210, 304);
            listBox1.TabIndex = 38;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;
            // 
            // BotonPausa
            // 
            BotonPausa.Location = new Point(420, 223);
            BotonPausa.Name = "BotonPausa";
            BotonPausa.Size = new Size(103, 23);
            BotonPausa.TabIndex = 38;
            BotonPausa.Text = "Pausa";
            BotonPausa.UseVisualStyleBackColor = true;
            BotonPausa.Click += BotonPausa_Click;
            // 
            // Juego1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BotonPausa);
            Controls.Add(tabControl1);
            Controls.Add(PuntosJ2);
            Controls.Add(PuntosJ1);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(BotonPaTurno1);
            Controls.Add(ImagenCJ1);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(NameCJ1);
            Controls.Add(TexTiempoTG1);
            Controls.Add(TexTiempoPG1);
            Controls.Add(TextBoxTiempoTG1);
            Controls.Add(TextBoxTiempoPG1);
            Controls.Add(BotonRepe1);
            Controls.Add(BotonEndGame1);
            Controls.Add(CajaJuego1);
            Name = "Juego1";
            Text = "Juego1";
            CajaJuego1.ResumeLayout(false);
            CajaJuego1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ImagenCJ1).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox ListaDePistas1;
        private Button BotonEndGame1;
        private GroupBox CajaJuego1;
        private Button BotonRepe1;
        private TextBox NameCJ1;
        private TextBox TextBoxTiempoPG1;
        private TextBox TextBoxTiempoTG1;
        private Label TexTiempoPG1;
        private Label TexTiempoTG1;
        private Label label4;
        private Label label6;
        private PictureBox ImagenCJ1;
        private Button BotonPaTurno1;
        private global::System.Windows.Forms.TextBox textBox220;
        private global::System.Windows.Forms.TextBox textBox221;
        private global::System.Windows.Forms.TextBox textBox222;
        private global::System.Windows.Forms.TextBox textBox223;
        private global::System.Windows.Forms.TextBox textBox202;
        private global::System.Windows.Forms.TextBox textBox203;
        private global::System.Windows.Forms.TextBox textBox204;
        private global::System.Windows.Forms.TextBox textBox205;
        private global::System.Windows.Forms.TextBox textBox206;
        private global::System.Windows.Forms.TextBox textBox207;
        private global::System.Windows.Forms.TextBox textBox208;
        private global::System.Windows.Forms.TextBox textBox209;
        private global::System.Windows.Forms.TextBox textBox211;
        private global::System.Windows.Forms.TextBox textBox184;
        private global::System.Windows.Forms.TextBox textBox185;
        private global::System.Windows.Forms.TextBox textBox186;
        private global::System.Windows.Forms.TextBox textBox187;
        private global::System.Windows.Forms.TextBox textBox188;
        private global::System.Windows.Forms.TextBox textBox189;
        private global::System.Windows.Forms.TextBox textBox190;
        private global::System.Windows.Forms.TextBox textBox171;
        private global::System.Windows.Forms.TextBox textBox172;
        private global::System.Windows.Forms.TextBox textBox173;
        private global::System.Windows.Forms.TextBox textBox174;
        private global::System.Windows.Forms.TextBox textBox151;
        private global::System.Windows.Forms.TextBox textBox152;
        private global::System.Windows.Forms.TextBox textBox153;
        private global::System.Windows.Forms.TextBox textBox154;
        private global::System.Windows.Forms.TextBox textBox155;
        private global::System.Windows.Forms.TextBox textBox156;
        private global::System.Windows.Forms.TextBox textBox157;
        private global::System.Windows.Forms.TextBox textBox158;
        private global::System.Windows.Forms.TextBox textBox161;
        private global::System.Windows.Forms.TextBox textBox162;
        private global::System.Windows.Forms.TextBox textBox163;
        private global::System.Windows.Forms.TextBox textBox164;
        private global::System.Windows.Forms.TextBox textBox165;
        private global::System.Windows.Forms.TextBox textBox136;
        private global::System.Windows.Forms.TextBox textBox137;
        private global::System.Windows.Forms.TextBox textBox138;
        private global::System.Windows.Forms.TextBox textBox139;
        private global::System.Windows.Forms.TextBox textBox140;
        private global::System.Windows.Forms.TextBox textBox141;
        private global::System.Windows.Forms.TextBox textBox142;
        private global::System.Windows.Forms.TextBox textBox143;
        private global::System.Windows.Forms.TextBox textBox144;
        private global::System.Windows.Forms.TextBox textBox145;
        private global::System.Windows.Forms.TextBox textBox146;
        private global::System.Windows.Forms.TextBox textBox147;
        private global::System.Windows.Forms.TextBox textBox148;
        private global::System.Windows.Forms.TextBox textBox149;
        private global::System.Windows.Forms.TextBox textBox121;
        private global::System.Windows.Forms.TextBox textBox122;
        private global::System.Windows.Forms.TextBox textBox123;
        private global::System.Windows.Forms.TextBox textBox124;
        private global::System.Windows.Forms.TextBox textBox125;
        private global::System.Windows.Forms.TextBox textBox126;
        private global::System.Windows.Forms.TextBox textBox127;
        private global::System.Windows.Forms.TextBox textBox130;
        private global::System.Windows.Forms.TextBox textBox131;
        private global::System.Windows.Forms.TextBox textBox132;
        private global::System.Windows.Forms.TextBox textBox133;
        private global::System.Windows.Forms.TextBox textBox109;
        private global::System.Windows.Forms.TextBox textBox110;
        private global::System.Windows.Forms.TextBox textBox111;
        private global::System.Windows.Forms.TextBox textBox112;
        private global::System.Windows.Forms.TextBox textBox113;
        private global::System.Windows.Forms.TextBox textBox114;
        private global::System.Windows.Forms.TextBox textBox115;
        private global::System.Windows.Forms.TextBox textBox116;
        private global::System.Windows.Forms.TextBox textBox117;
        private global::System.Windows.Forms.TextBox textBox93;
        private global::System.Windows.Forms.TextBox textBox94;
        private global::System.Windows.Forms.TextBox textBox95;
        private global::System.Windows.Forms.TextBox textBox96;
        private global::System.Windows.Forms.TextBox textBox97;
        private global::System.Windows.Forms.TextBox textBox98;
        private global::System.Windows.Forms.TextBox textBox99;
        private global::System.Windows.Forms.TextBox textBox100;
        private global::System.Windows.Forms.TextBox textBox101;
        private global::System.Windows.Forms.TextBox textBox102;
        private global::System.Windows.Forms.TextBox textBox103;
        private global::System.Windows.Forms.TextBox textBox104;
        private global::System.Windows.Forms.TextBox textBox105;
        private global::System.Windows.Forms.TextBox textBox78;
        private global::System.Windows.Forms.TextBox textBox79;
        private global::System.Windows.Forms.TextBox textBox80;
        private global::System.Windows.Forms.TextBox textBox81;
        private global::System.Windows.Forms.TextBox textBox82;
        private global::System.Windows.Forms.TextBox textBox83;
        private global::System.Windows.Forms.TextBox textBox84;
        private global::System.Windows.Forms.TextBox textBox86;
        private global::System.Windows.Forms.TextBox textBox87;
        private global::System.Windows.Forms.TextBox textBox61;
        private global::System.Windows.Forms.TextBox textBox62;
        private global::System.Windows.Forms.TextBox textBox63;
        private global::System.Windows.Forms.TextBox textBox64;
        private global::System.Windows.Forms.TextBox textBox65;
        private global::System.Windows.Forms.TextBox textBox66;
        private global::System.Windows.Forms.TextBox textBox68;
        private global::System.Windows.Forms.TextBox textBox69;
        private global::System.Windows.Forms.TextBox textBox70;
        private global::System.Windows.Forms.TextBox textBox71;
        private global::System.Windows.Forms.TextBox textBox72;
        private global::System.Windows.Forms.TextBox textBox73;
        private global::System.Windows.Forms.TextBox textBox74;
        private global::System.Windows.Forms.TextBox textBox48;
        private global::System.Windows.Forms.TextBox textBox50;
        private global::System.Windows.Forms.TextBox textBox53;
        private global::System.Windows.Forms.TextBox textBox54;
        private global::System.Windows.Forms.TextBox textBox55;
        private global::System.Windows.Forms.TextBox textBox56;
        private global::System.Windows.Forms.TextBox textBox57;
        private global::System.Windows.Forms.TextBox textBox31;
        private global::System.Windows.Forms.TextBox textBox32;
        private global::System.Windows.Forms.TextBox textBox33;
        private global::System.Windows.Forms.TextBox textBox34;
        private global::System.Windows.Forms.TextBox textBox35;
        private global::System.Windows.Forms.TextBox textBox36;
        private global::System.Windows.Forms.TextBox textBox40;
        private global::System.Windows.Forms.TextBox textBox41;
        private global::System.Windows.Forms.TextBox textBox42;
        private global::System.Windows.Forms.TextBox textBox18;
        private global::System.Windows.Forms.TextBox textBox26;
        private global::System.Windows.Forms.TextBox textBox27;
        private global::System.Windows.Forms.TextBox textBox5;
        private global::System.Windows.Forms.Label label1;
        private global::System.Windows.Forms.Label label2;
        private global::System.Windows.Forms.Label label3;
        private global::System.Windows.Forms.Label label5;
        private global::System.Windows.Forms.TextBox PuntosJ1;
        private global::System.Windows.Forms.TextBox PuntosJ2;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private ListBox listBox1;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox169;
        private System.Windows.Forms.Timer timer1;
        private Button BotonPausa;
    }
}