﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPrimeGame_0._1__BETA_
{
    public partial class Juego2 : Form
    {
        public Juego2()
        {
            InitializeComponent();
        }

        private void Juego2_Load(object sender, EventArgs e)
        {

        }

        private void BotonEndGame2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BotonPaTurno2_Click(object sender, EventArgs e)
        {

        }

        private void ImagenCJ2_Click(object sender, EventArgs e)
        {

        }

        private void BotonRepe2_Click(object sender, EventArgs e)
        {
            var variables = new ClassVariables(); // Crea una instancia de la clase ClassVariables si es necesario

            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void BotonPausa2_Click(object sender, EventArgs e)
        {

        }
    }
}
