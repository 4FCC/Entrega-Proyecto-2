﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiPrimeGame_0._1__BETA_
{
    public partial class VenHistorial : Form
    {
        private ClassVariables classVariables;

        public VenHistorial(ClassVariables variables)
        {
            InitializeComponent();
            classVariables = variables;
        }

        private void VenHistorial_Load(object sender, EventArgs e)
        {
            // En teoría debería mostrar los datos (Tiempo de partida, Nombre del ganador y Puntuación del ganador)
            string historial = "Tiempo de partida: " + classVariables.TiempoWin + " Nombre del ganador: " + classVariables.NombreWin + " Puntuación máxima: " + classVariables.PuntosWin;
            ListaHistorial.Items.Add(historial);
        }

        private void BotonCerrarHisto_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}