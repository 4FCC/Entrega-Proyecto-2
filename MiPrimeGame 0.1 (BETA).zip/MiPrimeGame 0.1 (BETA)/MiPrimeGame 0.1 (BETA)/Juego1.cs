﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace MiPrimeGame_0._1__BETA_
{
    public partial class Juego1 : Form
    {
        private readonly ClassVariables classVariables;
        private bool _botonPaTurno1Presionado;
        private int _tiempoPG1, _tiempoTG1;
        private int _PuntosJ1 = 0;
        private int _PuntosJ2 = 0;
        private string tempNombre;
        private VenHistorial venHistorial;

        public Juego1(ClassVariables variables)
        {
            InitializeComponent();
            classVariables = variables;
            _tiempoPG1 = classVariables.tiempoP;
            _tiempoTG1 = classVariables.tiempoT;
            TextBoxTiempoPG1.Text = _tiempoPG1.ToString();
            TextBoxTiempoTG1.Text = _tiempoTG1.ToString();
            ImagenCJ1.Image = classVariables.imagenJ1;
            NameCJ1.Text = classVariables.nombreJ1;
        }

        private void BotonEndGame1_Click(object sender, EventArgs e)
        {
            // 1. Registrar el tiempo transcurrido en TiempoWin
            classVariables.TiempoWin = _tiempoPG1;

            // 2. Registrar la cantidad mayor de puntos en PuntosWin
            classVariables.PuntosWin = Math.Max(_PuntosJ1, _PuntosJ2);

            // 3. Registrar el nombre del jugador que obtuvo más puntos en NombreWin
            if (_PuntosJ1 > _PuntosJ2)
            {
                classVariables.NombreWin = classVariables.nombreJ1;
            }
            else if (_PuntosJ2 > _PuntosJ1)
            {
                classVariables.NombreWin = classVariables.nombreJ2;
            }
            else
            {
                classVariables.NombreWin = "Empate";
            }

            // 4. Mostrar NombreWin en un mensaje
            MessageBox.Show("Fin de la partida, el ganador es: " + classVariables.NombreWin);

            Close();
        }

        private void BotonPaTurno1_Click(object sender, EventArgs e)
        {
            // Determinar puntos de los jugadores
            if (NameCJ1.Text == classVariables.nombreJ1)
            {
                _PuntosJ1++;
                PuntosJ1.Text = _PuntosJ1.ToString();
            }
            if (NameCJ1.Text == classVariables.nombreJ2)
            {
                _PuntosJ2++;
                PuntosJ2.Text = _PuntosJ2.ToString();
            }

            // Cambio de turno al presionar el botón
            if (BotonPaTurno1.Enabled)
            {
                _tiempoTG1 = 1;
            }
        }

        private void ImagenCJ1_Click(object sender, EventArgs e)
        {
            ImagenCJ1.Image = classVariables.imagenJ1;
        }

        private void BotonRepe1_Click(object sender, EventArgs e)
        {
            var juego2 = new Juego2();
            juego2.Show();
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 1000; // Configurar el intervalo en 1 segundo (1000 ms)

            _tiempoPG1--; // Restar 1 segundo al tiempo de los jugadores 1 y 2
            TextBoxTiempoPG1.Text = _tiempoPG1.ToString();
            if (_tiempoPG1 == 0)
            {
                BotonPaTurno1.Enabled = false;
                timer1.Stop();

                // Mostrar mensaje al terminar el tiempo de juego
                MessageBox.Show("Se acabó el tiempo. ¡Fin de la partida!");
            }

            _tiempoTG1--; // Restar 1 segundo al tiempo total
            TextBoxTiempoTG1.Text = _tiempoTG1.ToString();
            if (_tiempoTG1 == 0)
            {
                _tiempoTG1 = classVariables.tiempoT;
                // Reemplazar la imagenJ1 por imagenJ2 al terminar el tiempo total
                Image tempImagen = classVariables.imagenJ1;
                classVariables.imagenJ1 = classVariables.imagenJ2;
                classVariables.imagenJ2 = tempImagen;
                ImagenCJ1.Image = classVariables.imagenJ1;

                // Cambio de nombre al terminar el tiempo total
                if (NameCJ1.Text == classVariables.nombreJ1)
                {
                    NameCJ1.Text = classVariables.nombreJ2;
                }
                else if (NameCJ1.Text == classVariables.nombreJ2)
                {
                    NameCJ1.Text = classVariables.nombreJ1;
                }
            }
        }

        private void BotonPausa_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled) // Si el timer está en ejecución
            {
                // Pausar los timers
                timer1.Stop();

                // Bloquear el botón BotonPaTurno1
                BotonPaTurno1.Enabled = false;

                // Cambiar el texto del botón a "Continuar"
                BotonPausa.Text = "Continuar";
            }
            else // Si el timer está detenido
            {
                // Continuar los timers
                timer1.Start();

                // Desbloquear el botón BotonPaTurno1
                BotonPaTurno1.Enabled = true;

                // Cambiar el texto del botón a "Pausa"
                BotonPausa.Text = "Pausa";
            }
        }
    }
}
