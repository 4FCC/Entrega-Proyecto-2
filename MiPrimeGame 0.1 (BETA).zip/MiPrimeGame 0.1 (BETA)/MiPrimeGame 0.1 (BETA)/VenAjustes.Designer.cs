﻿namespace MiPrimeGame_0._1__BETA_
{
    partial class VenAjustes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VenAjustes));
            BotonGS = new Button();
            CajaAjustes = new GroupBox();
            BoxJ2 = new PictureBox();
            TextBoxTiempoT = new TextBox();
            TexTiempoT = new Label();
            TextBoxTiempoP = new TextBox();
            TexTiempoP = new Label();
            pictureBoxP5 = new PictureBox();
            pictureBoxP4 = new PictureBox();
            pictureBoxP3 = new PictureBox();
            pictureBoxP2 = new PictureBox();
            pictureBoxP1 = new PictureBox();
            TextoJ2 = new Label();
            TextoJ1 = new Label();
            BoxJ1 = new PictureBox();
            NameJ2 = new TextBox();
            NameJ1 = new TextBox();
            CajaAjustes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BoxJ2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BoxJ1).BeginInit();
            SuspendLayout();
            // 
            // BotonGS
            // 
            BotonGS.Location = new Point(211, 399);
            BotonGS.Name = "BotonGS";
            BotonGS.Size = new Size(384, 23);
            BotonGS.TabIndex = 18;
            BotonGS.Text = "Guardar y salir";
            BotonGS.UseVisualStyleBackColor = true;
            BotonGS.Click += BotonGS_Click;
            // 
            // CajaAjustes
            // 
            CajaAjustes.Controls.Add(BoxJ2);
            CajaAjustes.Controls.Add(TextBoxTiempoT);
            CajaAjustes.Controls.Add(TexTiempoT);
            CajaAjustes.Controls.Add(TextBoxTiempoP);
            CajaAjustes.Controls.Add(TexTiempoP);
            CajaAjustes.Controls.Add(pictureBoxP5);
            CajaAjustes.Controls.Add(pictureBoxP4);
            CajaAjustes.Controls.Add(pictureBoxP3);
            CajaAjustes.Controls.Add(pictureBoxP2);
            CajaAjustes.Controls.Add(pictureBoxP1);
            CajaAjustes.Controls.Add(TextoJ2);
            CajaAjustes.Controls.Add(TextoJ1);
            CajaAjustes.Controls.Add(BoxJ1);
            CajaAjustes.Controls.Add(NameJ2);
            CajaAjustes.Controls.Add(NameJ1);
            CajaAjustes.Location = new Point(12, 12);
            CajaAjustes.Name = "CajaAjustes";
            CajaAjustes.Size = new Size(776, 381);
            CajaAjustes.TabIndex = 19;
            CajaAjustes.TabStop = false;
            CajaAjustes.Text = "Ajustes de partida";
            // 
            // BoxJ2
            // 
            BoxJ2.Location = new Point(503, 65);
            BoxJ2.Name = "BoxJ2";
            BoxJ2.Size = new Size(124, 118);
            BoxJ2.SizeMode = PictureBoxSizeMode.Zoom;
            BoxJ2.TabIndex = 33;
            BoxJ2.TabStop = false;
            BoxJ2.Click += BoxJ2_Click;
            // 
            // TextBoxTiempoT
            // 
            TextBoxTiempoT.Location = new Point(326, 142);
            TextBoxTiempoT.Name = "TextBoxTiempoT";
            TextBoxTiempoT.Size = new Size(124, 23);
            TextBoxTiempoT.TabIndex = 32;
            TextBoxTiempoT.Text = "90";
            TextBoxTiempoT.TextAlign = HorizontalAlignment.Center;
            // 
            // TexTiempoT
            // 
            TexTiempoT.AutoSize = true;
            TexTiempoT.Location = new Point(336, 109);
            TexTiempoT.Name = "TexTiempoT";
            TexTiempoT.Size = new Size(105, 15);
            TexTiempoT.TabIndex = 31;
            TexTiempoT.Text = "Tiempo por turnos";
            // 
            // TextBoxTiempoP
            // 
            TextBoxTiempoP.Location = new Point(326, 65);
            TextBoxTiempoP.Name = "TextBoxTiempoP";
            TextBoxTiempoP.Size = new Size(124, 23);
            TextBoxTiempoP.TabIndex = 30;
            TextBoxTiempoP.Text = "300";
            TextBoxTiempoP.TextAlign = HorizontalAlignment.Center;
            TextBoxTiempoP.TextChanged += TextBoxTiempoP_TextChanged;
            // 
            // TexTiempoP
            // 
            TexTiempoP.AutoSize = true;
            TexTiempoP.Location = new Point(336, 29);
            TexTiempoP.Name = "TexTiempoP";
            TexTiempoP.Size = new Size(103, 15);
            TexTiempoP.TabIndex = 29;
            TexTiempoP.Text = "Tiempo de partida";
            // 
            // pictureBoxP5
            // 
            pictureBoxP5.Image = (Image)resources.GetObject("pictureBoxP5.Image");
            pictureBoxP5.Location = new Point(586, 233);
            pictureBoxP5.Name = "pictureBoxP5";
            pictureBoxP5.Size = new Size(124, 118);
            pictureBoxP5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxP5.TabIndex = 28;
            pictureBoxP5.TabStop = false;
            pictureBoxP5.Click += pictureBoxP5_Click_1;
            // 
            // pictureBoxP4
            // 
            pictureBoxP4.Image = (Image)resources.GetObject("pictureBoxP4.Image");
            pictureBoxP4.Location = new Point(456, 233);
            pictureBoxP4.Name = "pictureBoxP4";
            pictureBoxP4.Size = new Size(124, 118);
            pictureBoxP4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxP4.TabIndex = 27;
            pictureBoxP4.TabStop = false;
            pictureBoxP4.Click += pictureBoxP4_Click_1;
            // 
            // pictureBoxP3
            // 
            pictureBoxP3.Image = (Image)resources.GetObject("pictureBoxP3.Image");
            pictureBoxP3.Location = new Point(326, 233);
            pictureBoxP3.Name = "pictureBoxP3";
            pictureBoxP3.Size = new Size(124, 118);
            pictureBoxP3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxP3.TabIndex = 26;
            pictureBoxP3.TabStop = false;
            pictureBoxP3.Click += pictureBoxP3_Click;
            // 
            // pictureBoxP2
            // 
            pictureBoxP2.Image = (Image)resources.GetObject("pictureBoxP2.Image");
            pictureBoxP2.Location = new Point(196, 233);
            pictureBoxP2.Name = "pictureBoxP2";
            pictureBoxP2.Size = new Size(124, 118);
            pictureBoxP2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxP2.TabIndex = 25;
            pictureBoxP2.TabStop = false;
            pictureBoxP2.Click += pictureBoxP2_Click;
            // 
            // pictureBoxP1
            // 
            pictureBoxP1.Image = (Image)resources.GetObject("pictureBoxP1.Image");
            pictureBoxP1.Location = new Point(66, 233);
            pictureBoxP1.Name = "pictureBoxP1";
            pictureBoxP1.Size = new Size(124, 118);
            pictureBoxP1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxP1.TabIndex = 24;
            pictureBoxP1.TabStop = false;
            pictureBoxP1.Click += pictureBoxP1_Click;
            // 
            // TextoJ2
            // 
            TextoJ2.AutoSize = true;
            TextoJ2.Location = new Point(503, 29);
            TextoJ2.Name = "TextoJ2";
            TextoJ2.Size = new Size(124, 15);
            TextoJ2.TabIndex = 23;
            TextoJ2.Text = "Nombre del Jugador 2";
            // 
            // TextoJ1
            // 
            TextoJ1.AutoSize = true;
            TextoJ1.Location = new Point(147, 29);
            TextoJ1.Name = "TextoJ1";
            TextoJ1.Size = new Size(124, 15);
            TextoJ1.TabIndex = 22;
            TextoJ1.Text = "Nombre del Jugador 1";
            // 
            // BoxJ1
            // 
            BoxJ1.Location = new Point(147, 65);
            BoxJ1.Name = "BoxJ1";
            BoxJ1.Size = new Size(124, 118);
            BoxJ1.SizeMode = PictureBoxSizeMode.Zoom;
            BoxJ1.TabIndex = 20;
            BoxJ1.TabStop = false;
            BoxJ1.Click += BoxJ1_Click;
            // 
            // NameJ2
            // 
            NameJ2.Location = new Point(434, 189);
            NameJ2.Name = "NameJ2";
            NameJ2.Size = new Size(264, 23);
            NameJ2.TabIndex = 19;
            NameJ2.Text = "Jugador 2";
            // 
            // NameJ1
            // 
            NameJ1.Location = new Point(77, 189);
            NameJ1.Name = "NameJ1";
            NameJ1.Size = new Size(264, 23);
            NameJ1.TabIndex = 18;
            NameJ1.Text = "Jugador 1";
            // 
            // VenAjustes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CajaAjustes);
            Controls.Add(BotonGS);
            Name = "VenAjustes";
            Text = "VenAjustes";
            CajaAjustes.ResumeLayout(false);
            CajaAjustes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)BoxJ2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxP1).EndInit();
            ((System.ComponentModel.ISupportInitialize)BoxJ1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Button BotonGS;
        private GroupBox CajaAjustes;
        private Label TexTiempoP;
        private PictureBox pictureBoxP5;
        private PictureBox pictureBoxP4;
        private PictureBox pictureBoxP3;
        private PictureBox pictureBoxP2;
        private PictureBox pictureBoxP1;
        private Label TextoJ2;
        private Label TextoJ1;
        private PictureBox BoxJ1;
        private TextBox NameJ2;
        private TextBox NameJ1;
        private TextBox TextBoxTiempoT;
        private Label TexTiempoT;
        private TextBox TextBoxTiempoP;
        private PictureBox BoxJ2;
    }
}